﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Community.DataAccessLayer;
using System.Data;
using System.Data.OracleClient;

namespace DBConnectionTest
{
    class DBConnection
    {
        static public OracleConnection oraConn;
        static public string oraConnStr;

        static private string getoraConnStr()
        {
            if (oraConnStr == null || oraConnStr == "")
                oraConnStr = new DatabaseService().GetConnectionStringUsingService("ADEXA_SCMDEV", Environment.UserName, Environment.UserName);
            return oraConnStr;
        }

        public void getOraConn()
        {
            if(oraConn==null||oraConn.State==ConnectionState.Closed)
            {
                oraConn = new OracleConnection();
                oraConn.ConnectionString = getoraConnStr();
            }
        }

        //取整列
        public DataTable getOraData(String sql)
        {
            DataTable dt = new DataTable(); //新增空的table
            getOraConn();//連線
            using (oraConn)
            {
                oraConn.Open();//開啟連線
                using (OracleCommand cmd = new OracleCommand(sql, oraConn))
                {
                    OracleDataAdapter da = new OracleDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            return dt;
        }

        //取單筆資料
        public String getOraDataString(String sql)
        {
            String str = String.Empty;
            getOraConn();
            using (oraConn)
            {
                oraConn.Open();
                using (OracleCommand cmd = new OracleCommand(sql, oraConn))
                {
                    using (OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        while(dataReader.Read())
                        {
                            str = dataReader[0].ToString();
                        }
                    }
                }
            }
            return str;
        }
    }
}
