﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OracleClient;


namespace DBConnectionTest
{
    class Program
    {
        static private DBConnection db = new DBConnection();

        //印出整個table
        static void Main(string[] args)
        {
            string sql1 = "SELECT * FROM ADEXA.A";
            DataTable dt1 = db.getOraData(sql1);

            Console.WriteLine("sql1:");

            for (int r=0; r<dt1.Rows.Count;r++)
            {
                for(int c=0;c<dt1.Columns.Count;c++)
                {
                    
                    Console.Write(dt1.Rows[r][c].ToString() + ";");
                  
                }
            }

            Console.WriteLine();

            //印出單筆
            string sql2 = "SELECT cust FROM ADEXA.A";
            string result = db.getOraDataString(sql2);
            Console.WriteLine("sql2:");
            Console.Write(result);
            Console.Read();
                     
       }

        static private void tryInsert()
        {
            string sql1 = "SELCET lc FROM ADEXA.A";
            string result = db.getOraDataString(sql1);

            db.getOraConn();

            using (DBConnection.oraConn)
            {
                DBConnection.oraConn.Open();


            }
        }
    }
}
