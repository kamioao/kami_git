﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OracleClient;


namespace DBConnectionTest
{
    class Program
    {
        static private DBConnection db = new DBConnection();
        static public OracleConnection oraConn;
        static void Main(string[] args)
        {
            //DBConnection db = new DBConnection();

            //Datatable
            string sql1 = "select * from adexa.t_scm_qcm_qty_diff_combine_tmp where rownum = 1 ";
            DataTable dt1 = db.getOraData(sql1);

            Console.WriteLine("sql1:");

            for (int r = 0; r < dt1.Rows.Count; r++)
            {
                for (int c = 0; c < dt1.Columns.Count; c++)
                {
                    Console.Write(dt1.Rows[r][c].ToString() + " ; ");
                }
            }

            //Datastring
            string sql2 = "select test_device from adexa.t_scm_qcm_qty_diff_combine_tmp where rownum = 1 ";
            string result = db.getOraDataString(sql2);
            Console.WriteLine("sql2:");
            Console.Write(result);

            //insert into 
            processInsert();
        }

        static private void processInsert()
        {
            string sql1 = "select test_device from adexa.t_scm_qcm_qty_diff_combine_tmp where rownum = 1 ";
            string result = db.getOraDataString(sql1);

            db.getOraConnection();            

            using (DBConnection.oraConn)
            {
                DBConnection.oraConn.Open();
                
                string sql = "insert into adexa.t_scm_qcm_qty_diff_combine_dat(test_device) values(:test_device) ";
                string sql2 = "update adexa.t_scm_qcm_qty_diff_combine_dat set t.test_device = :test_device2 ";
                OracleCommand cmd = new OracleCommand(sql, DBConnection.oraConn);
                OracleTransaction odt = DBConnection.oraConn.BeginTransaction();
                cmd.Transaction = odt;

                cmd.Parameters.AddWithValue("test_device", result);
                cmd.Parameters.AddWithValue("test_device2", "test");
                cmd.ExecuteNonQuery();
                odt.Commit();
            }

        }
    }
}
