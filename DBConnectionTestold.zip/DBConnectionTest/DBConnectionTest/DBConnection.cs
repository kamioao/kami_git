﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Community.DataAccessLayer;
using System.Data;
using System.Data.OracleClient;

namespace DBConnectionTest
{
    class DBConnection
    {
        static public OracleConnection oraConn;
        static public string oraSCMDBConnStrUsingService;
        static public string oraSCMDBConnStr;

        static private string getSCMDBConnStrUsingService()
        {            
            if(oraSCMDBConnStrUsingService == null || oraSCMDBConnStrUsingService == "")
                oraSCMDBConnStrUsingService = new DatabaseService().GetConnectionStringUsingService("ADEXA_SCMDEV", Environment.UserName, Environment.UserName);
            return oraSCMDBConnStrUsingService;
        }

        static private string getSCMDBConnStr()
        {
            if (oraSCMDBConnStr == null || oraSCMDBConnStr == "")
                oraSCMDBConnStr = new DatabaseService().GetConnectionString("scmdev", "adexa");
            return oraSCMDBConnStr;
        }

        static private string getSCMDBConnStr2()
        {
            if (oraSCMDBConnStr == null || oraSCMDBConnStr == "")
                oraSCMDBConnStr = "Data Source=scmdev;Persist Security Info=True;User ID=adexa;Password=axeda;Unicode=True";
            return oraSCMDBConnStr;
        }

        public void getOraConnection()
        {
            if (oraConn == null || oraConn.State == ConnectionState.Closed)
            {
                oraConn = new OracleConnection();
                oraConn.ConnectionString = getSCMDBConnStrUsingService(); //using service
                //oraConn.ConnectionString = getSCMDBConnStr();
                //oraConn.ConnectionString = getSCMDBConnStr2();
            }
        }

        public DataTable getOraData(String sql)
        {
            DataTable dt = new DataTable();
            getOraConnection();
            using (oraConn)
            {
                oraConn.Open();
                using (OracleCommand cmd = new OracleCommand(sql, oraConn))
                {
                    cmd.CommandTimeout = 300;
                    OracleDataAdapter da = new OracleDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            return dt;
        }

        public String getOraDataString(String sql)
        {
            String str = String.Empty;
            getOraConnection();
            using (oraConn)
            {
                oraConn.Open();
                using (OracleCommand cmd = new OracleCommand(sql, oraConn))
                {
                    cmd.CommandTimeout = 300;
                    using (OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        while (dataReader.Read())
                        {
                            str = dataReader[0].ToString();
                        }
                    }
                }
            }
            return str;
        }
    }
}
