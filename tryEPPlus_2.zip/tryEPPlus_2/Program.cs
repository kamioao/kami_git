﻿using System;
using System.Data;
using System.Data.OracleClient;
using System.Data.SqlClient;
using System.IO;

namespace tryEPPlus_2
{
    class Program
    {
        static private Writexlsx wrirtedown = new Writexlsx();
        static private DBConn db = new DBConn();

        static void Main(string[] args)
        {
            DataTable dt2 = wrirtedown.ImportToDataTable(@"H:\exercise\BUMP_FLOW_(Security C).xlsx", "BUMP_FLOW");

            //開新檔案
            FileStream files = new FileStream(@"H:\exercise\test.csv", FileMode.Create);
            files.Close();

            //把Datatable存進.csv檔
            using (StreamWriter swExtLogFile = new StreamWriter(@"H:\exercise\test.csv"))
            {               
                int i;
                //swExtLogFile.Write(Environment.NewLine);               
                foreach (DataRow dtrow in dt2.Rows)
                {
                    object[] array = dtrow.ItemArray;
                    for (i = 0; i < array.Length - 1; i++)
                    {
                        swExtLogFile.Write(array[i].ToString() + ",");
                    }
                    swExtLogFile.WriteLine(array[i].ToString());
                }
            }
            //swExtLogFile.Flush();
            //swExtLogFile.Close();

            //tryInsert();
            tryprint();

        }

        static private void tryprint()
        {
            DataTable dt4 = wrirtedown.ImportToDataTable(@"H:\exercise\BUMP_FLOW_(Security C).xlsx", "BUMP_FLOW");
            for(int i=0; i<dt4.Columns.Count; i++)
            {
                Console.Write(dt4.Columns[i].ColumnName.ToString() + ",");
            }
            Console.Read();

        }

        //把Datatable存進Database
        static private void tryInsert()
        {
            
            string sqlcomddel = "DELETE FROM adexa.t_gm_bump_flow_kami";

            DataTable dt3 = wrirtedown.ImportToDataTable(@"H:\exercise\BUMP_FLOW_(Security C).xlsx", "BUMP_FLOW");
            string sqlcomd = "INSERT INTO adexa.t_gm_bump_flow_kami (flow, recpid, pkg_type, operation) VALUES (:flow, :recpid, :pkg_type, :operation)";

            db.getOraConnection();
       
            using (DBConn.oraConn)
            {
                DBConn.oraConn.Open();

                OracleCommand cmd = DBConn.oraConn.CreateCommand();
                OracleTransaction transaction;

                // Start a local transaction
                transaction = DBConn.oraConn.BeginTransaction(IsolationLevel.ReadCommitted);
                // Assign transaction object for a pending local transaction
                cmd.Transaction = transaction;

                try
                {
                    cmd.CommandText = sqlcomddel;
                    cmd.ExecuteNonQuery();

                    cmd.CommandText = sqlcomd;                    
                    foreach (DataRow r in dt3.Rows)
                    {
                        cmd.Parameters.AddWithValue(":flow", r["flow"]);
                        cmd.Parameters.AddWithValue(":recpid", r["recpid"]);
                        cmd.Parameters.AddWithValue(":pkg_type", r["pkg_type"]);
                        cmd.Parameters.AddWithValue(":operation", r["operation"]);
                        cmd.ExecuteNonQuery();
                    }
                    transaction.Commit();
                    Console.WriteLine("All records are written to database.");
                    Console.ReadLine();
                }
                catch (Exception e)
                {
                    transaction.Rollback();
                    //Console.WriteLine(e.ToString());
                    Console.WriteLine("error: Neither record was written to database.");
                    Console.ReadLine();
                }

            }
        }
    }
}
