﻿using Community.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OracleClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tryEPPlus_2
{
    class DBConn
    {
        static public OracleConnection oraConn;
        static public string oraSCMDBConnStrUsingService;

        static private string getSCMDBConnStrUsingService()
        {
            if (oraSCMDBConnStrUsingService == null || oraSCMDBConnStrUsingService == "")
                oraSCMDBConnStrUsingService = new DatabaseService().GetConnectionStringUsingService("ADEXA_SCMDEV", Environment.UserName, Environment.UserName);
            return oraSCMDBConnStrUsingService;
        }

        public void getOraConnection()
        {
            if (oraConn == null || oraConn.State == ConnectionState.Closed)
            {
                oraConn = new OracleConnection();
                oraConn.ConnectionString = getSCMDBConnStrUsingService(); //using service
            }
        }

    }
}
