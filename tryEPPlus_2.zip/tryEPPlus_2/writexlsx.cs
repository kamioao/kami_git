﻿using OfficeOpenXml;
using System;
using System.Data;
using System.IO;
using System.Linq;

namespace tryEPPlus_2
{
    class Writexlsx
    {
        public DataTable ImportToDataTable(string FilePath, string SheetName)
        {
            DataTable dtwrite = new DataTable();
            FileInfo fi = new FileInfo(FilePath);

            //Check if the file exists
            if (!fi.Exists)
                throw new Exception("File" + FilePath + "Does Not Exists");

            using (ExcelPackage xlPackage = new ExcelPackage(fi))
            {
                //ExcelWorksheet worksheet = xlPackage.Workbook.Worksheets[1]; //抓第1個sheet
                ExcelWorksheet worksheet = xlPackage.Workbook.Worksheets[SheetName]; //抓指定的sheet名稱

                //Check if the sheet exists
                if (worksheet == null)
                {
                    throw new Exception("Sheet" + SheetName + "Does Not Exists");
                }

                // Fetch the WorkSheet size
                ExcelCellAddress startCell = worksheet.Dimension.Start;
                ExcelCellAddress endCell = worksheet.Dimension.End;

                //if (endCell.Column != 10)
                //{
                //    throw new Exception("欄位數不符");
                //}

                // create all the needed DataColumn 
                for (int col = startCell.Column; col <= endCell.Column; col++)
                    dtwrite.Columns.Add(worksheet.Cells[1, col].Value.ToString()); //第1列為Column Name

                // place all the data into DataTable
                for (int row = 2; row <= endCell.Row; row++)
                {
                    ExcelRange range = worksheet.Cells[row, startCell.Column, row, endCell.Column];

                    if (range.Any(c => !string.IsNullOrEmpty(c.Text)) == false)
                    {
                        continue;  //略過此列
                    }

                    DataRow dr = dtwrite.NewRow();
                    for (int col = startCell.Column; col <= endCell.Column; col++)
                    {
                        //DataTable欄位數從0開始
                        dr[col - 1] = Convert.ToString(worksheet.Cells[row, col].Value);
                    }
                    dtwrite.Rows.Add(dr);
                }
                return dtwrite;
            }
        }
    }
}
